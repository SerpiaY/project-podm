export interface viewVehicle {
    vehicleid : number,
    brand : String,
    branchid : number,
    branchAddress : String,
    costperday : number,
    dateBought : Date,
}