export interface viewRent {
    rent_id : number;
    vehicle_id : number;
    trip_duration : number;
    customer_id : number;
    date_rented : Date;
    date_returned : Date;
  }