
import { Component, OnDestroy } from '@angular/core';
import { FormControl, Validators, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon'
import {MatFormFieldModule} from '@angular/material/form-field';
import { ReplaySubject, merge, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import {MatDividerModule} from '@angular/material/divider';
import {provideNativeDateAdapter} from '@angular/material/core';
import {MatDatepickerModule} from '@angular/material/datepicker';
const today = new Date();
const month = today.getMonth();
const year = today.getFullYear();

@Component({
  selector: 'app-edit-rent',
  standalone: true,
  imports: [MatIconModule,ReactiveFormsModule, MatFormFieldModule, MatInputModule, FormsModule, MatDividerModule, MatDatepickerModule, FormsModule],
  templateUrl: './edit-rent.component.html',
  styleUrl: './edit-rent.component.css',
  providers: [provideNativeDateAdapter()],
})
export class EditRentComponent implements OnDestroy{
  vehicleControl = new FormControl('', [Validators.required])
  customerControl = new FormControl('', [Validators.required])
  durationControl = new FormControl('', [Validators.required])
  DateControl = new FormControl('', [Validators.required])
  rentIDControl = new FormControl('', [Validators.required])

  rentErrorMessage = ''
  
  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);

  constructor(
    private httpClient: HttpClient,
    private router: Router,
  ) {
    merge(this.customerControl.statusChanges, this.customerControl.valueChanges)
      .pipe(takeUntil(this.destroyed$))
      .subscribe(() => this.updateErrorMessage());
  }
  updateErrorMessage() {
    if (this.customerControl.hasError('required'), this.vehicleControl.hasError, this.durationControl.hasError, this.DateControl.hasError) {
      this.rentErrorMessage = 'You must enter a value';
    } else {
      this.rentErrorMessage = '';
    }
  }
  onRentEditButton(){
    console.log('Sending to API with ', this.vehicleControl.getRawValue(), this.customerControl.getRawValue(), this.DateControl.getRawValue(), this.durationControl.getRawValue() );
    this.httpClient.post('http://localhost:8081/editrent', {
      rentid : this.rentIDControl.getRawValue(),
      vehicleid : this.vehicleControl.getRawValue(),
      tripduration : this.durationControl.getRawValue(),
      customerid : this.customerControl.getRawValue(),
      daterented : this.DateControl.getRawValue(),
    }).pipe(takeUntil(this.destroyed$)).subscribe((data) => {
      console.log('Call log in return ', data);
      if (data!= null) {
        this.router.navigate(['/', 'view-rents']);
      }
    });
 }
 ngOnDestroy(): void {
  this.destroyed$.next(true);
  this.destroyed$.complete();
}
}
