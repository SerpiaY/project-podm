import { Component, OnDestroy} from '@angular/core';
import {FormControl, Validators, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon'
import {MatFormFieldModule} from '@angular/material/form-field';
import { ReplaySubject, merge, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import {MatDividerModule} from '@angular/material/divider';
import {provideNativeDateAdapter} from '@angular/material/core';
import {MatDatepickerModule} from '@angular/material/datepicker';

@Component({
  selector: 'app-create-vehicle',
  standalone: true,
  imports: [MatIconModule,ReactiveFormsModule, MatFormFieldModule, MatInputModule, FormsModule, MatDividerModule, MatDatepickerModule, FormsModule],
  templateUrl: './create-vehicle.component.html',
  styleUrl: './create-vehicle.component.css',
  providers: [provideNativeDateAdapter()],
})
export class CreateVehicleComponent implements OnDestroy{
  brandNameControl = new FormControl('', [Validators.required])
  costControl = new FormControl('', [Validators.required])
  dateBoughtControl = new FormControl('', [Validators.required])
  branchIDControl = new FormControl('', [Validators.required])
  ngOnDestroy(): void {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);

  constructor(
    private httpClient: HttpClient,
    private router: Router,
  ) {
    merge(this.brandNameControl.statusChanges)
      .pipe(takeUntil(this.destroyed$))
      .subscribe();
  }
  onVehicleSubmitButton(){
    console.log('Sending to API with ', this.brandNameControl.getRawValue(), this.costControl.getRawValue(), this.dateBoughtControl.getRawValue());
    this.httpClient.post('http://localhost:8081/create-car', {
      branchid : this.branchIDControl.getRawValue(),
      costperday : this.costControl.getRawValue(),
      brand : this.brandNameControl.getRawValue(),
      datebought : this.dateBoughtControl.getRawValue(),
    }).pipe(takeUntil(this.destroyed$)).subscribe((data) => {
      console.log('Call create vehicle ', data);
      if (data!= null) {
        this.router.navigate(['/', 'welcome']);
      }
    });
 }
}
