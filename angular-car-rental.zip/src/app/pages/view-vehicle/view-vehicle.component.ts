import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy } from '@angular/core';
import {MatTableModule} from '@angular/material/table';
import { viewRent } from '../../model/rent';
import { Router } from '@angular/router';
import { ReplaySubject, merge, takeUntil } from 'rxjs';
import { viewVehicle } from '../../model/vehicle';

@Component({
  selector: 'app-view-vehicle',
  standalone: true,
  imports: [MatTableModule],
  templateUrl: './view-vehicle.component.html',
  styleUrl: './view-vehicle.component.css'
})
export class ViewVehicleComponent implements OnDestroy {
  vehicleData : viewVehicle[] = []
  displayedColumns: string[] = ['vehicle_id', 'brand', 'branchAddress', 'date_bought', 'cost_per_day',];
  dataSource = this.vehicleData;

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);

  constructor(
    private httpClient: HttpClient,
    private router: Router,
  ) {
    merge(this.displayedColumns)
      .pipe(takeUntil(this.destroyed$))
      .subscribe();
  }
  
  onDirectToPage() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.get('http://localhost:8081/view-vehicles', {
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data != null) {
        this.vehicleData = data;
        this.dataSource = this.vehicleData;
        console.log(this.dataSource);
      }
    });
  }
  ngOnDestroy(): void {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }
  viewAvail1() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.get('http://localhost:8081/view-avail1', {
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data != null) {
        this.vehicleData = data;
        this.dataSource = this.vehicleData;
        console.log(this.dataSource);
      }
    });
  }
  viewAvail2() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.get('http://localhost:8081/view-avail2', {
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data != null) {
        this.vehicleData = data;
        this.dataSource = this.vehicleData;
        console.log(this.dataSource);
      }
    });
  }
  viewAvail3() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.get('http://localhost:8081/view-avail3', {
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data != null) {
        this.vehicleData = data;
        this.dataSource = this.vehicleData;
        console.log(this.dataSource);
      }
    });
  }
}
