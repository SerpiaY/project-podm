import { Routes } from '@angular/router';
import { WelcomeComponent } from './pages/welcome/welcome.component';
import { CreateRentComponent } from './pages/create-rent/create-rent.component';
import { EditRentComponent } from './pages/edit-rent/edit-rent.component';
import { ViewRentsComponent } from './pages/view-rents/view-rents.component';
import { CreateUserComponent } from './pages/create-user/create-user.component';
import { LogInComponent } from './pages/log-in/log-in.component';
import { ViewUserComponent } from './pages/view-user/view-user.component';
import { CreateVehicleComponent } from './pages/create-vehicle/create-vehicle.component';
import { ViewVehicleComponent } from './pages/view-vehicle/view-vehicle.component';
import { ViewPaymentComponent } from './pages/view-payment/view-payment.component';

export const routes: Routes = [
    {
        title: 'Login Page',
        path: 'log-in',
        component: LogInComponent,
    },
    {
        title: 'Welcome to Car Rental',
        path: 'welcome',
        component: WelcomeComponent,
    },
    {
        title: 'Create Rent',
        path: 'create-rent',
        component: CreateRentComponent,
    },
    {
        title: 'Edit Rent',
        path: 'edit-rent',
        component: EditRentComponent,
    },
    {
        title: 'View All Rents',
        path: 'view-rents',
        component: ViewRentsComponent,
    },
    {
        title: 'Create User',
        path: 'create-user',
        component: CreateUserComponent,
    },
    {
        title: 'View All Users',
        path: 'view-user',
        component: ViewUserComponent,
    },
    {
        title: 'Create A Nice Car!',
        path: 'create-car',
        component: CreateVehicleComponent,
    },
    {
        title: 'View all Car!',
        path: 'view-vehicle',
        component: ViewVehicleComponent,
    },
    {
        title: 'View all Bill!',
        path: 'view-payment',
        component: ViewPaymentComponent,
    },
];
