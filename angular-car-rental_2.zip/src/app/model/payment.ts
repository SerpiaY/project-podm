export interface viewPayment {
    rent_id : number;
    payment_id : number;
    amount : number;
    payday : Date;
  }