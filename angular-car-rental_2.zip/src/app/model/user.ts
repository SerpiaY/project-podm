export interface viewUser {
    id : number,
    firstName : String,
    lastName : String,
    username : String,
    password : String,
    licenseNumber : number,
    dateBirth : Date,
    phone : String,
  }