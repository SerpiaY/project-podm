import { Component, OnDestroy } from '@angular/core';
import {FormControl, Validators, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatFormFieldModule} from '@angular/material/form-field';
import { ReplaySubject, merge, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-log-in',
  standalone: true,
  imports: [ReactiveFormsModule, MatFormFieldModule, MatInputModule, FormsModule],
  templateUrl: './log-in.component.html',
  styleUrl: './log-in.component.css'
})
export class LogInComponent implements OnDestroy {
  emailControl = new FormControl('', [Validators.required, Validators.email]);
  passwordControl = new FormControl('', [Validators.required]);

  emailErrorMessage = '';
  passwordMessage = '';

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);

  constructor(
    private httpClient: HttpClient,
    private router: Router,
  ) {
    merge(this.emailControl.statusChanges, this.emailControl.valueChanges)
      .pipe(takeUntil(this.destroyed$))
      .subscribe(() => this.updateErrorMessage());
  }

  updateErrorMessage() {
    if (this.emailControl.hasError('required')) {
      this.emailErrorMessage = 'You must enter a value';
    } else if (this.emailControl.hasError('email')) {
      this.emailErrorMessage = 'Not a valid email';
    } else {
      this.emailErrorMessage = '';
    }
  }

  updatePasswordErrorMessage() {
    if (this.passwordControl.hasError('required')) {
      this.passwordMessage = 'You must enter your password';
    } else {
      this.passwordMessage = '';
    }
  }

  isLogInButtonDisable() {
    return !this.emailControl.valid || !this.passwordControl.valid;
  }

  onLogInButtonClick() {
    console.log('Calling API with ', this.emailControl.getRawValue(), ' and ', this.passwordControl.getRawValue());
    this.httpClient.post('http://localhost:8081/login', {
      username: this.emailControl.getRawValue(),
      password: this.passwordControl.getRawValue(),
    }).pipe(takeUntil(this.destroyed$)).subscribe((data) => {
      console.log('Call log in return ', data);
      if (data) {
        this.router.navigate(['/', 'view-rents']);
      }else {
        this.emailControl.patchValue('');
        this.passwordControl.patchValue('');
      }
    });
  }

  ngOnDestroy(): void {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }
}