import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy, } from '@angular/core';
import {MatTableModule} from '@angular/material/table';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon'
import { viewRent } from '../../model/rent';
import { Router } from '@angular/router';
import { ReplaySubject, merge, takeUntil } from 'rxjs';
import { MatFormField } from '@angular/material/form-field';
import { FormControl,ReactiveFormsModule, Validators, } from '@angular/forms';

@Component({
  selector: 'app-view-rents',
  standalone: true,
  imports: [MatTableModule, MatFormField, ReactiveFormsModule, MatInputModule, MatIconModule],
  templateUrl: './view-rents.component.html',
  styleUrl: './view-rents.component.css'
})
export class ViewRentsComponent implements OnDestroy{
  rentData : viewRent[] = []
  displayedColumns: string[] = ['rent_id', 'vehicle_id', 'trip_duration', 'customer_id', 'date_rented', 'date_returned',];
  dataSource = this.rentData;

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  rentIDControl = new FormControl('', [Validators.required,])
  constructor(
    private httpClient: HttpClient,
    private router: Router,
  ) {
    merge(this.displayedColumns)
      .pipe(takeUntil(this.destroyed$))
      .subscribe();
  }
  
  onDirectToPage() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.get('http://localhost:8081/viewall', {
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data != null) {
        this.rentData = data;
        this.dataSource = this.rentData;
        console.log(this.dataSource);
      }
    });
  }
  deleteByID() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.post('http://localhost:8081/deletebyID', {
      rentid : this.rentIDControl.getRawValue(),
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
    });
  }
  deleteAll() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.post('http://localhost:8081/delete-all-rent', {
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data!=null){
        this.onDirectToPage()
      }
    });
  }
  ngOnDestroy(): void {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }
}
