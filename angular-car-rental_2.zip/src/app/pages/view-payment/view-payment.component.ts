
import { HttpClient } from '@angular/common/http';
import { Component, OnDestroy } from '@angular/core';
import {MatTableModule} from '@angular/material/table';
import { MatFormField } from '@angular/material/form-field';
import { FormControl,ReactiveFormsModule, Validators, } from '@angular/forms';
import { Router } from '@angular/router';
import { ReplaySubject, merge, takeUntil } from 'rxjs';
import { viewVehicle } from '../../model/vehicle';
import { viewPayment } from '../../model/payment';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon'
@Component({
  selector: 'app-view-payment',
  standalone: true,
  imports: [MatTableModule, MatFormField, ReactiveFormsModule, MatInputModule, MatIconModule],
  templateUrl: './view-payment.component.html',
  styleUrl: './view-payment.component.css'
})
export class ViewPaymentComponent {
  paymentData : viewPayment[] = []
  displayedColumns: string[] = ['rentID','paymentID', 'payment_amount', 'payment_date',];
  dataSource = this.paymentData;

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  paymentIDcontrol = new FormControl('', [Validators.required,])
  constructor(
    private httpClient: HttpClient,
    private router: Router,
  ) {
    merge(this.displayedColumns)
      .pipe(takeUntil(this.destroyed$))
      .subscribe();
  }
  
  onDirectToPage() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.get('http://localhost:8081/view-payment', {
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data != null) {
        this.paymentData = data;
        this.dataSource = this.paymentData;
        console.log(this.dataSource);
      }
    });
  }
  paytheBills() {
    console.log('Current Columns ', this.displayedColumns, this.paymentIDcontrol.getRawValue());
    this.httpClient.post('http://localhost:8081/pay', {
      payment_id : this.paymentIDcontrol.getRawValue(),
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data != null) {
        this.paymentData = data;
        this.dataSource = this.paymentData;
        console.log(this.dataSource);
      }
    });
  }
  ngOnDestroy(): void {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }
}
