import { Component} from '@angular/core';
import {FormControl, Validators, FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon'
import {MatFormFieldModule} from '@angular/material/form-field';
import { ReplaySubject, merge, takeUntil } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import {MatDividerModule} from '@angular/material/divider';
import {provideNativeDateAdapter} from '@angular/material/core';
import {MatDatepickerModule} from '@angular/material/datepicker';

const today = new Date();
const month = today.getMonth();
const year = today.getFullYear();
@Component({
  selector: 'app-create-user',
  standalone: true,
  imports: [MatIconModule,ReactiveFormsModule, MatFormFieldModule, MatInputModule, FormsModule, MatDividerModule, MatDatepickerModule, FormsModule],
  templateUrl: './create-user.component.html',
  styleUrl: './create-user.component.css',
  providers: [provideNativeDateAdapter()],
})
export class CreateUserComponent {
  firstNameControl = new FormControl('', [Validators.required])
  lastNameControl = new FormControl('', [Validators.required])
  usernameControl = new FormControl('', [Validators.required, Validators.email])
  passwordControl = new FormControl('', [Validators.required])
  licenseNumberControl = new FormControl('', Validators.required)
  dateBirthControl = new FormControl('', [Validators.required, Validators.minLength(2)])
  phoneNumberControl = new FormControl('', [Validators.required])

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);

  constructor(
    private httpClient: HttpClient,
    private router: Router,
  ) {
    merge(this.usernameControl.statusChanges, this.passwordControl.valueChanges)
      .pipe(takeUntil(this.destroyed$))
      .subscribe(() => this.updateErrorMessage());
  }

  emailErrorMessage = '';
  passwordMessage = '';
  updateErrorMessage() {
    if (this.usernameControl.hasError('required')) {
      this.emailErrorMessage = 'You must enter a value';
    } else if (this.usernameControl.hasError('email')) {
      this.emailErrorMessage = 'Not a valid email';
    } else {
      this.emailErrorMessage = '';
    }
  }
  updatePasswordErrorMessage() {
    if (this.passwordControl.hasError('required')) {
      this.passwordMessage = 'You must enter your password';
    } else {
      this.passwordMessage = '';
    }
  }

  onCreateSubmitButton(){
    console.log('Sending to API with ', this.dateBirthControl.getRawValue(), this.firstNameControl.getRawValue(), this.lastNameControl.getRawValue(), this.usernameControl.getRawValue(), this.passwordControl.getRawValue());
    this.httpClient.post('http://localhost:8081/signup', {
      firstName : this.firstNameControl.getRawValue(),
      lastName : this.lastNameControl.getRawValue(),
      username : this.usernameControl.getRawValue(),
      password : this.passwordControl.getRawValue(),
      licenseNumber : this.licenseNumberControl.getRawValue(),
      phone : this.phoneNumberControl.getRawValue(),
      dateBirth : this.dateBirthControl.getRawValue(),
    }).pipe(takeUntil(this.destroyed$)).subscribe((data) => {
      console.log('Call log in return ', data);
      if (data!= null) {
        this.router.navigate(['/', 'view-user']);
      }
    });
 }
}
