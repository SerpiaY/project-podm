
import { HttpClient } from '@angular/common/http';
import {MatTableModule} from '@angular/material/table';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon'
import { Component, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { ReplaySubject, merge, takeUntil } from 'rxjs';
import { viewUser } from '../../model/user';
import { MatFormField } from '@angular/material/form-field';
import { FormControl } from '@angular/forms';
import {ReactiveFormsModule, Validators, } from '@angular/forms';
@Component({
  selector: 'app-view-user',
  standalone: true,
  imports: [MatTableModule, MatFormField, ReactiveFormsModule, MatInputModule, MatIconModule],
  templateUrl: './view-user.component.html',
  styleUrl: './view-user.component.css'
})
export class ViewUserComponent implements OnDestroy{
  userData : viewUser[] = []
  displayedColumns: string[] = ['id', 'first_name', 'last_name', 'username', 'licenseNumber', 'date', 'phone'];
  dataSource = this.userData;

  private destroyed$: ReplaySubject<boolean> = new ReplaySubject(1);
  UserIDControl = new FormControl('', [Validators.required,])
  constructor(
    private httpClient: HttpClient,
    private router: Router,
  ) {
    merge(this.displayedColumns)
      .pipe(takeUntil(this.destroyed$))
      .subscribe();
  }
  
  onDirectToPage() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.get('http://localhost:8081/viewallusers', {
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data != null) {
        this.userData = data;
        this.dataSource = this.userData;
        console.log(this.dataSource);
      }
    });
  }
  deleteByID() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.post('http://localhost:8081/deleteuserID', {
      id : this.UserIDControl.getRawValue(),
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data!=null){
        this.onDirectToPage()
      }
    });
  }
  deleteAll() {
    console.log('Current Columns ', this.displayedColumns);
    this.httpClient.post('http://localhost:8081/deleteallusers', {
    }).pipe(takeUntil(this.destroyed$)).subscribe((data : any) => {
      console.log('Call Show data return ', data);
      if(data!=null){
        this.onDirectToPage()
      }
    });
  }
  ngOnDestroy(): void {
    this.destroyed$.next(true);
    this.destroyed$.complete();
  }
}
